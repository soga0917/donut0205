<?php include 'header.php';?>

      <nav class="gMenu">
        <input class="menu-btn" type="checkbox" id="menu-btn">
        <label class="menu-icon" for="menu-btn">
          <span class="navicon"></span>
        </label>
        <ul class="menu">
          <li><a href="index.php">top</a></li>
          <li><a href="products.php">商品一覧</a></li>
          <li><a href="qanda.php">よくある質問</a></li>
          <li><a href="toiawase.php">問い合わせ</a></li>
          <li><a href="policy.php">当サイトのポリシー</a></li>
  </ul>
      </nav>
      <a href="index.php"><h1><img src="../images/top/spHeaderlogo.png" alt="spHeaderlogo"></h1></a>
      <div class="cart">
      <div><img src="../images/top/loginLogo.png" alt="loginLogo">  </div>
      <div><img src="../images/top/cartLogo.png" alt=""></div>  
      </div>

      <div class="kennSaku2">  
   
   <!-- スペース仮 -->
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <!-- スペース仮 -->
   
   <img src="../images/top/Search.png" alt="">
   </div>
   </header>

<div class="kennSaku">
<?php 
echo 'ようこそ&nbsp;&nbsp;ゲスト様';
?>
</div>

<main>
<div class="㏄DoughnutImg">  


</form>
</main>
</div>    
</body>
</article>


<?php include 'footer.php';?>
