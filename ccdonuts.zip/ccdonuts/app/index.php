<?php include 'header.php';?>

<nav class="gMenu">
  <input class="menu-btn" type="checkbox" id="menu-btn">
  <label class="menu-icon" for="menu-btn">
    <span class="navicon"></span>
  </label>
  
  <ul class="menu">
  <li><a href="index.php">top</a></li>
          <li><a href="products.php">商品一覧</a></li>
          <li><a href="qanda.php">よくある質問</a></li>
          <li><a href="toiawase.php">問い合わせ</a></li>
          <li><a href="policy.php">当サイトのポリシー</a></li>
  </ul>



</nav>

<a href="index.php">
<h1>
<img class="spHeaderlogo" src="../images/top/spHeaderlogo.png" alt="spHeaderlogo" class="pc">
</h1> 
</a>
<div class="cart">
      <div><img src="../images/top/loginLogo.png" alt="loginLogo"  class="pc">  
</div>
<div><a href="cartin.php"><img src="../images/top/cartLogo.png" alt=""></a></div>  
      </div>
<div class="kennSaku2">  
   
   <!-- スペース仮 -->
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&emsp;&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;
   &emsp;&emsp;&emsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <!-- スペース仮 -->
   
<a class="spichiran" href="products.php"> 
<img src="../images/top/Search.png" alt="">

</a>
  
  </div> 
   </div>

  </header>

<div class="kennSaku">
<?php 
echo 'ようこそ&nbsp;&nbsp;ゲスト様';
?>
</div>

<main>

<div>
<img src="../images/top/pcMainimg.png" alt="pcMainimg" class="pc">
</div>

<div>
<img src="../images/top/heroImg.png" class="logoMobile">

</div>
<div class="newandLife">

<a href="#">
  <img src="../images/top/newImg.png" alt="" class="pc">
  <img src="../images/top/spnewImg.png" class="logoMobile">
</a> 

<a href="#"> 
  <img src="../images/top/donutLife.png" alt="donutLife" class="pc">
  <img src="../images/top/spdonutLife.png" class="logoMobile">
</a>

</div>

  <a href="products.php"> 
  <div class="ichiranImg"><img src="../images/top/ichiranImg.png" alt="" class="pc"></div>
  </a>

<div class="shoukaiImg">

</div>  


</div>

  <div class="rankBest3">
  <h3>
  <img src="../images/top/midashiImg.png" alt="midashiImg">
  </h3>
  <ul class="rankImg">

  <li>
    <div class="rankLogo">
    <img src="../images/top/rank1Logo.png" alt="rank1" class="pc">
    <!-- <img src="../images/top/sprank1Logo.png" alt="rank1" class="logoMobile"> -->
    </div> 
<a href="cart.php"><div><img src="../images/top/pcCdonutimg.png" alt="pcCdonutimg" class="pc"></div></a> 
<div class="price">
        <p>CCドーナツ 当店オリジナル（5個入り）</p>   
        <p class="tax">税込  ￥1,500</p> 
        <form action="">
        </form>
  </div>
  </li>

  <li>
        <div class="rankLogo">
        <img src="../images/top/rank2Logo.png" alt="rank2" class="pc">
        <!-- <img src="../images/top/sprank2Logo.png" alt="rank2" class="logoMobile"> -->
        </div>
        <a href="cart02.php"><div><img src="../images/top/fruitDonut12img.png" alt="pcCdonutimg" class="pc"></div></a>
        <div class="price">
        <p>フルーツドーナツセット（12個入り）</p>   
          <p class="tax">税込  ￥3,500</p>     
          <form action="">
          </form>
  </div>
  </li>

  <li>
      <div class="rankLogo">
      <img src="../images/top/rank3Logo.png" alt="rank3" class="pc">
      <!-- <img src="../images/top/sprank3Logo.png" alt="rank5" class="logoMobile"> -->
      </div>
      <a href="#"><div><img src="../images/top/fruitDonut14img.png" alt="pcCdonutimg" class="pc"></div></a>
  <div class="price">    
        <p>フルーツドーナツセット（14個入り）</p>
        <p class="tax">税込  ￥4,000</p>  
        <form action="">
        </form>
  </div>
  </li>

  </ul>  
</div> 

<div class="rankBest6"> 
  <ul class="rankImg">

  <li>
    <div class="rankLogo">
    <img src="../images/top/rank4Logo.png" alt="rank4" class="pc">
    <!-- <img src="../images/top/sprank4Logo.png" alt="rank4" class="logoMobile"> -->
    </div>
    <a href="#"><div><img src="../images/top/chocolateDeraito.png" alt="chocolateDeraito" class="pc"></div></a>
  <div class="price">
      <p>チョコレートデライト（5個入り）</p>
      <p class="tax">税込  ￥1,600</p>    
      <form action="">
      </form>
  </div>  
  </li>
  
  <li>
    <div class="rankLogo">
    <img src="../images/top/rank5Logo.png" alt="rank5" class="pc">
    <!-- <img src="../images/top/sprank5Logo.png" alt="rank5" class="logoMobile"> -->
    </div>

    <a href="#"><div><img src="../images/top/bestSelectionbox.png" alt="bestSelectionbox" class="pc"></div></a>
  <div class="price">
      <p>ベストセレクションボックス（4個入り）</p>
      <p class="tax">税込  ￥1,200</p>  
      <form action="">
      </form>
  </div>
  </li>
  
  <li>
    <div class="rankLogo">
    <img src="../images/top/rank6Logo.png" alt="rank6" class="pc">
    <!-- <img src="../images/top/sprank6Logo.png" alt="rank5" class="logoMobile"> -->
    </div>
    <a href="#"><div><img src="../images/top/strawberryCrash.png" alt="strawberryCrash" class="pc"></div></a>
  <div class="price">
      <p>ストロベリークラッシュ（5個入り）</p> 
      <p class="tax">税込  ￥1,800</p>   
      <form action="">
      </form>
  </div>
  </li>

  </ul>
  </div>   
</div> 
</main>
</div>
  </body>
</article>
</div>
<?php include 'footer.php';?>
