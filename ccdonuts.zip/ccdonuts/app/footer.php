<footer class="footer">

  <ul>
    <li><a href="qanda.php">よくある質問&emsp;</a></li>
    <li><a href="toiawase.php">お問い合わせ&emsp;</a></li>
    <li><a href="policy.php">当サイトのポリシー&emsp;</a></li>
  </ul>


<a href="index.php">
<p>
<img src="../images/top/bigpcHeaderlogo.png" alt="" class="pc">
<img class="spHeaderframe" src="../images/top/spHeaderframe.png" alt="" class="logoMobile">
</p>
</a>

<div class="snsFlex">
<img src="../images/top/faceBookicon.png" alt="">
<img src="../images/top/InstagraMicon.png" alt="">
<img src="../images/top/TwitterIcon.png" alt="">


</div>


</footer>    
<div><img src="../images/top/copyrightImg.png" alt="copyrightImg"> </div>  
</html>